import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class PasswordApp {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Password Analyzer 🔐");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 150);
        frame.setLayout(new FlowLayout());

        JLabel label = new JLabel("Enter Password:");
        JTextField passwordField = new JTextField(20);
        JButton analyzeButton = new JButton("Analyze");
        JLabel resultLabel = new JLabel("Strength: ");

        analyzeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String input = passwordField.getText();
                String result = PasswordAnalyzer.analyzePassword(input);
                resultLabel.setText("Strength: " + result);
            }
        });

        frame.add(label);
        frame.add(passwordField);
        frame.add(analyzeButton);
        frame.add(resultLabel);
        frame.setVisible(true);
    }
}